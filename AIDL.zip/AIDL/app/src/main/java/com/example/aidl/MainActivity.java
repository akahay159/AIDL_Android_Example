package com.example.aidl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText firstNumber, secondNumber;
    TextView resultNumber;
    Button multiplybtn;
    IMyAidlInterface myInterface;
    /// this will be our client that is main activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstNumber = findViewById(R.id.number1);
        secondNumber = findViewById(R.id.number2);
        multiplybtn = findViewById(R.id.multiplybtn);
        resultNumber = findViewById(R.id.multiresult);
        multiplybtn.setOnClickListener(MainActivity.this);
        //bind this service with the client
        Intent multiplyservice = new Intent(MainActivity.this,MultiplicationService.class);
        bindService(multiplyservice, myserviceconnection, Context.BIND_AUTO_CREATE);// Intentservice, service connection, flags
    }

    // create the object of the service connection// this is the interface

    ServiceConnection myserviceconnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // connecting this service to the binder
            myInterface = IMyAidlInterface.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @Override
    public void onClick(View view) {
        int first = Integer.parseInt(firstNumber.getText().toString());
        int second = Integer.parseInt(secondNumber.getText().toString());
        try {
             int result = myInterface.multiplyTwoValue(first,second);
            resultNumber.setText(result + "");
        } catch (RemoteException e) {
            e.printStackTrace();
        }


    }
}