package com.example.aidl;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

public class MultiplicationService extends Service {
    public MultiplicationService() {
    }

    @Override
    public IBinder onBind(Intent intent) {

        return myBinder;
    }
    IMyAidlInterface.Stub myBinder = new IMyAidlInterface.Stub() {
        @Override
        public int multiplyTwoValue(int firstName, int secondName)
                throws RemoteException {

            return firstName * secondName;
        }
    };
}